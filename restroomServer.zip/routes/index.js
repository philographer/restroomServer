var app = require('../app');
var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

router.get('/restroom', function(req, res) {
  app.dbService.findRestroom(minLat, maxLat, minLng, maxLng).then(function(result){
    res.status(200).json(result);
  }).catch(function(error){
    res.status(500).json({error: "error"});
  });
});

router.post('/restroom', function(req, res) {
  app.dbService.createRestroom(req.body).then(function(result){
    res.status(200).json(result);
  }).catch(function(error){
    res.status(500).json({error: "error"});
  });
});

router.post('/restroom/comment', function(req, res){
  app.dbService.createComment(req.body).then(function(result){
    res.status(200).json(result);
  }).catch(function(error){
    res.status(500).json(error.message);
  });
});

router.get('/restroom/comment', function(req, res){
  app.dbService.readComment(req.query).then(function(result){
    if(result.length == 0){
      res.status(200).json({msg: "Not Founded"});
    }else{
      res.status(200).json(result);
    }
  }).catch(function(error){
    res.status(500).json(error.message);
  });
});

module.exports = router;
